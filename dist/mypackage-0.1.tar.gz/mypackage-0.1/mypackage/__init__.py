import myModule
